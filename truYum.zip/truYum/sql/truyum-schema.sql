create database truyum;

create table menu_item(
menuId       int          not null primary key,
name         varchar(20)  not null,
price        decimal(7,2) not null,
active       varchar(10)  not null,
dateOfLaunch date         not null,
category     varchar(30)  not null,
freeDelivery varchar(10)  not null,
action       varchar (10) not null
);


create table user(
userId   int         not null primary key,
userName varchar(30) not null,
userType varchar(30) not null
);


create table cart(
cartId int not null primary key,
menuId int,
userId int,
foreign key (userId) REFERENCES user(userId),
foreign key (menuId) references menu_item(menuId)
);